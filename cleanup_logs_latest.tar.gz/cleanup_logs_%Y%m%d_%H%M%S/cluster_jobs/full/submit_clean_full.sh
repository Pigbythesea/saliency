#!/usr/bin/env bash
set -euo pipefail
source /scratch/tshu2/zzhan330/miniconda3/etc/profile.d/conda.sh
conda activate hma
cd /scratch/tshu2/zzhan330/saliency
mkdir -p slurm_logs outputs/paper1_publication_v0/preflight/cluster_submissions
python scripts/generate_paper1_publication_preflight.py
if [[ "full" == "full" ]]; then
  python scripts/verify_paper1_clean_rerun_authorization.py --strict
fi
BEHAVIOR=$(sbatch --parsable outputs/paper1_publication_v0/preflight/cluster_jobs/full/clean_behavior_cells.sbatch)
NEURAL_EXPORT=$(sbatch --parsable outputs/paper1_publication_v0/preflight/cluster_jobs/full/clean_neural_exports.sbatch)
NEURAL_ANALYSIS=$(sbatch --parsable --dependency=afterok:$NEURAL_EXPORT \
  outputs/paper1_publication_v0/preflight/cluster_jobs/full/clean_neural_analysis.sbatch)
GEOMETRY=$(sbatch --parsable --dependency=afterok:$NEURAL_ANALYSIS \
  outputs/paper1_publication_v0/preflight/cluster_jobs/full/clean_geometry_collect.sbatch)
EFFICIENCY=$(sbatch --parsable outputs/paper1_publication_v0/preflight/cluster_jobs/full/clean_efficiency_cells.sbatch)
printf 'mode=full\n'
printf 'behavior=%s\n' "$BEHAVIOR"
printf 'neural_export=%s\n' "$NEURAL_EXPORT"
printf 'neural_analysis=%s\n' "$NEURAL_ANALYSIS"
printf 'geometry_collect=%s\n' "$GEOMETRY"
printf 'efficiency=%s\n' "$EFFICIENCY"

MATERIALIZE=$(sbatch --parsable --dependency=afterok:$BEHAVIOR:$GEOMETRY:$EFFICIENCY \
  outputs/paper1_publication_v0/preflight/cluster_jobs/full/clean_materialize_axes.sbatch)
printf 'materialize_axes=%s\n' "$MATERIALIZE"

