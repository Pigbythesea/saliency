# Postrun Import Validation Plan

Do not interpret scientific results during import validation.

Required checks after user-run cluster outputs are copied back:

1. Regenerate preflight with `cmd.exe` command `.\.venv\Scripts\python.exe scripts\generate_paper1_publication_preflight.py`.
2. Rerun authorization verification with `.\.venv\Scripts\python.exe scripts\verify_paper1_clean_rerun_authorization.py`.
3. Confirm `outputs\paper1_publication_v0\behavioral\aggregate.csv` exists and contains only publication-root behavioral rows.
4. Confirm `outputs\paper1_publication_v0\neural_encoding\encoding_scores.csv` exists and retains subject/ROI/stream scope.
5. Confirm `outputs\paper1_publication_v0\geometry\geometry_scores.csv` exists and retains subject/ROI/stream scope.
6. Confirm `outputs\paper1_publication_v0\efficiency\efficiency_profiles.csv` and `resource_allocation_profiles.csv` exist or missingness is audited.
7. Confirm `outputs\paper1_publication_v0\cross_axis\model_axis_scores.csv` uses only publication-root inputs.
8. Confirm no `_admission_panel`, Matrix V1, Matrix V2, legacy, or scaffold paths are merged into clean evidence.
9. Update `outputs\paper1_publication_v0\audits\clean_rerun_audit.csv` with exact missing/failing rows before any interpretation.
