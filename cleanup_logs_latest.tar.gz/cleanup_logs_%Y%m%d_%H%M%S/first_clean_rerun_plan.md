# First Clean Rerun Plan

authorization_status: authorized

## Eligible Models

- behavioral: adaptivenn_deit_small|center_prior|coco_search18_task_prior|convnext_tiny|deepgaze_iie|deepgaze_iii|deepgaze_msdb|deit_small_static|dinov3_small_patch16|dynamicvit_deit_small_keep_0_7|empirical_spatial_prior|hat|hiera_tiny|mambavision_t|random_baseline|resnet50|scandiff_freeview|scandiff_visual_search|siglip_base_patch16|swin_tiny_patch4_window7_224|swinv2_tiny_window8_256|tome_deit_small_r13|vit_base_patch16_224|vit_base_patch16_clip_224|vit_small_patch14_dinov2
- latent_neural_geometry: adaptivenn_deit_small|convnext_tiny|deepgaze_iie|deepgaze_iii|deepgaze_msdb|deit_small_static|dinov3_small_patch16|dynamicvit_deit_small_keep_0_7|hat|hiera_tiny|mambavision_t|resnet50|scandiff_freeview|scandiff_visual_search|siglip_base_patch16|swin_tiny_patch4_window7_224|swinv2_tiny_window8_256|tome_deit_small_r13|vit_base_patch16_224|vit_base_patch16_clip_224|vit_small_patch14_dinov2
- task_search_or_scanpath: adaptivenn_deit_small|deepgaze_iii|hat|scandiff_freeview|scandiff_visual_search
- efficiency_resource: adaptivenn_deit_small|center_prior|coco_search18_task_prior|convnext_tiny|deepgaze_iie|deepgaze_iii|deepgaze_msdb|deit_small_static|dinov3_small_patch16|dynamicvit_deit_small_keep_0_7|empirical_spatial_prior|hat|hiera_tiny|mambavision_t|random_baseline|resnet50|scandiff_freeview|scandiff_visual_search|siglip_base_patch16|swin_tiny_patch4_window7_224|swinv2_tiny_window8_256|tome_deit_small_r13|vit_base_patch16_224|vit_base_patch16_clip_224|vit_small_patch14_dinov2

## ROI Stream Scope

- available_subject_roi_pairs: subj01:V1|subj01:V2|subj01:V3|subj01:hV4|subj01:lateral|subj01:midlateral|subj01:midparietal|subj01:midventral|subj01:parietal|subj01:ventral|subj02:V1|subj02:V2|subj02:V3|subj02:hV4|subj03:V1|subj03:V2|subj03:V3|subj03:hV4|subj04:V1|subj04:V2|subj04:V3|subj04:hV4

## Cluster Commands

Preflight authorizes only the bounded clean rerun scope in this file. Codex did not launch a cluster job.
Run these cmd.exe commands to sync the cluster workspace and re-check preflight before any axis-specific clean rerun job:

```cmd
ssh zzhan330@dsailogin.arch.jhu.edu "cd /scratch/tshu2/zzhan330/saliency && git pull"
ssh zzhan330@dsailogin.arch.jhu.edu "cd /scratch/tshu2/zzhan330/saliency && ./.venv/bin/python scripts/generate_paper1_publication_preflight.py"
ssh zzhan330@dsailogin.arch.jhu.edu "cd /scratch/tshu2/zzhan330/saliency && cat outputs/paper1_publication_v0/preflight/rerun_readiness_table.csv"
```

No single full publication-matrix runner is registered in `scripts/`; do not use the admission-panel runner as a substitute.

## Expected Output Validation

`outputs/paper1_publication_v0/preflight/expected_outputs_manifest.csv` lists required pre-rerun and post-rerun artifacts.
