# User-Run Cluster Commands

These are cmd.exe-compatible commands. They intentionally do not use PowerShell.

The cluster environment is `/scratch/tshu2/zzhan330/miniconda3` with `conda activate hma`.

Run full clean jobs only after `authorization_verification_table.csv` and `execution_path_verification_table.csv` contain only passing/ready rows. Do not substitute `scripts/run_paper1_admission_panel.py` for clean publication-root evidence.

## 1. Sync Workspace

```cmd
cd /d D:\Git\saliency
ssh zzhan330@dsailogin.arch.jhu.edu "mkdir -p /scratch/tshu2/zzhan330/saliency"
ssh zzhan330@dsailogin.arch.jhu.edu "cd /scratch/tshu2/zzhan330/saliency && git pull"
scp configs\paper1_clean_behavioral_rerun.yaml zzhan330@dsailogin.arch.jhu.edu:/scratch/tshu2/zzhan330/saliency/configs/
scp configs\paper1_latent_neural_matrix.yaml zzhan330@dsailogin.arch.jhu.edu:/scratch/tshu2/zzhan330/saliency/configs/
scp configs\paper1_efficiency_resource_rerun.yaml zzhan330@dsailogin.arch.jhu.edu:/scratch/tshu2/zzhan330/saliency/configs/
scp configs\paper1_cross_axis_assembly.yaml zzhan330@dsailogin.arch.jhu.edu:/scratch/tshu2/zzhan330/saliency/configs/
scp configs\paper1_publication_contract.yaml zzhan330@dsailogin.arch.jhu.edu:/scratch/tshu2/zzhan330/saliency/configs/
scp scripts\generate_paper1_publication_preflight.py zzhan330@dsailogin.arch.jhu.edu:/scratch/tshu2/zzhan330/saliency/scripts/
scp scripts\verify_paper1_clean_rerun_authorization.py zzhan330@dsailogin.arch.jhu.edu:/scratch/tshu2/zzhan330/saliency/scripts/
scp scripts\paper1_clean_rerun_common.py zzhan330@dsailogin.arch.jhu.edu:/scratch/tshu2/zzhan330/saliency/scripts/
scp scripts\run_paper1_clean_behavioral_rerun.py zzhan330@dsailogin.arch.jhu.edu:/scratch/tshu2/zzhan330/saliency/scripts/
scp scripts\run_paper1_clean_latent_neural_encoding.py zzhan330@dsailogin.arch.jhu.edu:/scratch/tshu2/zzhan330/saliency/scripts/
scp scripts\run_paper1_clean_geometry.py zzhan330@dsailogin.arch.jhu.edu:/scratch/tshu2/zzhan330/saliency/scripts/
scp scripts\run_paper1_clean_efficiency_resource.py zzhan330@dsailogin.arch.jhu.edu:/scratch/tshu2/zzhan330/saliency/scripts/
scp scripts\assemble_paper1_clean_cross_axis.py zzhan330@dsailogin.arch.jhu.edu:/scratch/tshu2/zzhan330/saliency/scripts/
scp scripts\export_external_prediction_maps.py zzhan330@dsailogin.arch.jhu.edu:/scratch/tshu2/zzhan330/saliency/scripts/
scp scripts\prepare_paper1_clean_behavior_cell.py zzhan330@dsailogin.arch.jhu.edu:/scratch/tshu2/zzhan330/saliency/scripts/
scp scripts\run_paper1_clean_cell_job.py zzhan330@dsailogin.arch.jhu.edu:/scratch/tshu2/zzhan330/saliency/scripts/
scp scripts\create_paper1_clean_cluster_jobs.py zzhan330@dsailogin.arch.jhu.edu:/scratch/tshu2/zzhan330/saliency/scripts/
```

## 2. Environment Activation

```cmd
ssh zzhan330@dsailogin.arch.jhu.edu "source /scratch/tshu2/zzhan330/miniconda3/etc/profile.d/conda.sh && conda activate hma && cd /scratch/tshu2/zzhan330/saliency && python --version"
```

## 3. Cache And Checkpoint Verification

```cmd
ssh zzhan330@dsailogin.arch.jhu.edu "source /scratch/tshu2/zzhan330/miniconda3/etc/profile.d/conda.sh && conda activate hma && cd /scratch/tshu2/zzhan330/saliency && python scripts/generate_paper1_publication_preflight.py"
ssh zzhan330@dsailogin.arch.jhu.edu "source /scratch/tshu2/zzhan330/miniconda3/etc/profile.d/conda.sh && conda activate hma && cd /scratch/tshu2/zzhan330/saliency && python scripts/verify_paper1_clean_rerun_authorization.py"
ssh zzhan330@dsailogin.arch.jhu.edu "cd /scratch/tshu2/zzhan330/saliency && cat outputs/paper1_publication_v0/preflight/authorization_verification_table.csv"
ssh zzhan330@dsailogin.arch.jhu.edu "cd /scratch/tshu2/zzhan330/saliency && cat outputs/paper1_publication_v0/preflight/execution_path_verification_table.csv"
```

## 4. Small Verification Job

This job validates the clean runner dry-run paths only. It does not create clean publication-root evidence.

```cmd
ssh zzhan330@dsailogin.arch.jhu.edu "source /scratch/tshu2/zzhan330/miniconda3/etc/profile.d/conda.sh && conda activate hma && cd /scratch/tshu2/zzhan330/saliency && python scripts/run_paper1_clean_behavioral_rerun.py --dry-run"
ssh zzhan330@dsailogin.arch.jhu.edu "source /scratch/tshu2/zzhan330/miniconda3/etc/profile.d/conda.sh && conda activate hma && cd /scratch/tshu2/zzhan330/saliency && python scripts/run_paper1_clean_latent_neural_encoding.py --dry-run"
ssh zzhan330@dsailogin.arch.jhu.edu "source /scratch/tshu2/zzhan330/miniconda3/etc/profile.d/conda.sh && conda activate hma && cd /scratch/tshu2/zzhan330/saliency && python scripts/run_paper1_clean_geometry.py --dry-run"
ssh zzhan330@dsailogin.arch.jhu.edu "source /scratch/tshu2/zzhan330/miniconda3/etc/profile.d/conda.sh && conda activate hma && cd /scratch/tshu2/zzhan330/saliency && python scripts/run_paper1_clean_efficiency_resource.py --dry-run"
ssh zzhan330@dsailogin.arch.jhu.edu "source /scratch/tshu2/zzhan330/miniconda3/etc/profile.d/conda.sh && conda activate hma && cd /scratch/tshu2/zzhan330/saliency && python scripts/assemble_paper1_clean_cross_axis.py --dry-run"
ssh zzhan330@dsailogin.arch.jhu.edu "source /scratch/tshu2/zzhan330/miniconda3/etc/profile.d/conda.sh && conda activate hma && cd /scratch/tshu2/zzhan330/saliency && python scripts/verify_paper1_clean_rerun_authorization.py --strict"
```

## 5. Generate Clean Cell Cluster Jobs

These commands generate Slurm scripts and job tables only. They do not run the clean rerun.

```cmd
ssh zzhan330@dsailogin.arch.jhu.edu "source /scratch/tshu2/zzhan330/miniconda3/etc/profile.d/conda.sh && conda activate hma && cd /scratch/tshu2/zzhan330/saliency && python scripts/create_paper1_clean_cluster_jobs.py --mode smoke --max-items 8"
ssh zzhan330@dsailogin.arch.jhu.edu "source /scratch/tshu2/zzhan330/miniconda3/etc/profile.d/conda.sh && conda activate hma && cd /scratch/tshu2/zzhan330/saliency && python scripts/create_paper1_clean_cluster_jobs.py --mode full"
ssh zzhan330@dsailogin.arch.jhu.edu "cd /scratch/tshu2/zzhan330/saliency && cat outputs/paper1_publication_v0/preflight/cluster_jobs/smoke/clean_cluster_job_manifest.json && cat outputs/paper1_publication_v0/preflight/cluster_jobs/full/clean_cluster_job_manifest.json"
```

## 6. Submit Smoke Verification Jobs

This submits a tiny bounded cluster verification subset under `outputs/paper1_publication_v0/preflight/smoke_cells/`; it is not clean publication evidence.

```cmd
ssh zzhan330@dsailogin.arch.jhu.edu "source /scratch/tshu2/zzhan330/miniconda3/etc/profile.d/conda.sh && conda activate hma && cd /scratch/tshu2/zzhan330/saliency && bash outputs/paper1_publication_v0/preflight/cluster_jobs/smoke/submit_clean_smoke.sh"
```

## 7. Full Clean Job Commands

```cmd
ssh zzhan330@dsailogin.arch.jhu.edu "source /scratch/tshu2/zzhan330/miniconda3/etc/profile.d/conda.sh && conda activate hma && cd /scratch/tshu2/zzhan330/saliency && bash outputs/paper1_publication_v0/preflight/cluster_jobs/full/submit_clean_full.sh"
```

## 8. Log Monitoring

Use these only after a verified full job command has been launched.

```cmd
ssh zzhan330@dsailogin.arch.jhu.edu "cd /scratch/tshu2/zzhan330/saliency && tail -n 100 outputs/paper1_publication_v0/logs/behavioral_clean_rerun.log"
ssh zzhan330@dsailogin.arch.jhu.edu "cd /scratch/tshu2/zzhan330/saliency && tail -n 100 outputs/paper1_publication_v0/logs/neural_encoding_clean_rerun.log"
ssh zzhan330@dsailogin.arch.jhu.edu "cd /scratch/tshu2/zzhan330/saliency && tail -n 100 outputs/paper1_publication_v0/logs/geometry_clean_rerun.log"
ssh zzhan330@dsailogin.arch.jhu.edu "cd /scratch/tshu2/zzhan330/saliency && tail -n 100 outputs/paper1_publication_v0/logs/efficiency_clean_rerun.log"
```

## 9. Output Verification

```cmd
ssh zzhan330@dsailogin.arch.jhu.edu "source /scratch/tshu2/zzhan330/miniconda3/etc/profile.d/conda.sh && conda activate hma && cd /scratch/tshu2/zzhan330/saliency && python scripts/verify_paper1_clean_rerun_authorization.py"
ssh zzhan330@dsailogin.arch.jhu.edu "cd /scratch/tshu2/zzhan330/saliency && test -f outputs/paper1_publication_v0/behavioral/aggregate.csv && test -f outputs/paper1_publication_v0/neural_encoding/encoding_scores.csv && test -f outputs/paper1_publication_v0/geometry/geometry_scores.csv && test -f outputs/paper1_publication_v0/efficiency/efficiency_profiles.csv && test -f outputs/paper1_publication_v0/cross_axis/model_axis_scores.csv"
```

## 10. Copy Back

```cmd
cd /d D:\Git\saliency
scp -r zzhan330@dsailogin.arch.jhu.edu:/scratch/tshu2/zzhan330/saliency/outputs/paper1_publication_v0 outputs\
```

## 11. Import Validation

```cmd
cd /d D:\Git\saliency
.\.venv\Scripts\python.exe scripts\generate_paper1_publication_preflight.py
.\.venv\Scripts\python.exe scripts\verify_paper1_clean_rerun_authorization.py
type outputs\paper1_publication_v0\preflight\authorization_verification_table.csv
type outputs\paper1_publication_v0\preflight\execution_path_verification_table.csv
```
