# DeepGaze Hook Audit

Generated: 2026-06-18T21:07:05.502323+00:00

## DeepGaze IIE

- Adapter: `adapter_certified`
- Candidate latent hooks: `models.0.features|models.0.saliency_networks.0.conv2|models.0.finalizers.0`
- Behavioral output: `human_gaze_density`
- User action: `none`

## DeepGaze III

- Adapter: `adapter_certified`
- Conditional hooks: `features|saliency_networks.0.conv2|scanpath_networks.0.conv1|fixation_selection_networks.0.conv2`
- Behavioral outputs: `conditional_next_fixation|generated_scanpath`
- Resource outputs: `fixation_count|history_length|stopping_behavior|scanpath_length`
- Command attempted: `.\.venv\Scripts\python.exe scripts\certify_local_publication_models.py --models deepgaze_iii`
- Blockers: `none`
- Next command: `.\.venv\Scripts\python.exe scripts\certify_local_publication_models.py --models deepgaze_iii`

## DeepGaze MSDB

- Adapter: `adapter_certified`
- Candidate latent hooks: `features|features.backbone.feature_extractors.CLIP|features.backbone.feature_extractors.DINOv2|saliency_network.conv4`
- Behavioral output: `human_gaze_density`
- User action: `none`
